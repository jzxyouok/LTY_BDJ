//
//  UIView+Additions.h
//  WeiboCloned
//
//  Created by ZhaoFucheng on 14-8-29.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Additions)

- (UIViewController *)viewController;

@end
