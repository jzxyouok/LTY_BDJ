#import <Foundation/NSString.h>

@interface NSString (HexConversion)
-(NSInteger)hexValue;
@end