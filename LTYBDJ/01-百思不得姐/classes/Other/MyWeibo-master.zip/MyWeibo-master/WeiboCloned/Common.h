//
//  Common.h
//  WeiboCloned
//
//  Created by 赵 福成 on 14-6-26.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#ifndef WeiboCloned_Common_h
#define WeiboCloned_Common_h


#endif

//Label Color key
#define kNavigationBarTitleColor @"NavigationBarTitleColor"
#define kTableViewCellTextColor @"TableViewCellTextColor"

#define kSkinName @"kSkinName"