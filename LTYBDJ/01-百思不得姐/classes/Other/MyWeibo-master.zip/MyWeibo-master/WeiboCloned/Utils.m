//
//  Utils.m
//  WeiboCloned
//
//  Created by 赵 福成 on 14-6-23.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#import "Utils.h"

float CurrentVersion()
{
   return [[[UIDevice currentDevice] systemVersion] floatValue];
}

