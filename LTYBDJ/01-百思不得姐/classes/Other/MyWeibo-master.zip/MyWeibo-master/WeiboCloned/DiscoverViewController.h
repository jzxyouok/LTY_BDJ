//
//  DiscoverViewController.h
//  WeiboCloned
//  广场视图控制器
//  Created by 赵 福成 on 14-6-23.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#import "BaseViewController.h"

@interface DiscoverViewController : BaseViewController

@end
