//
//  AuthorizeWebViewController.h
//  WeiboCloned
//
//  Created by 赵 福成 on 14-6-28.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#import "BaseViewController.h"

@interface AuthorizeWebViewController : BaseViewController<UIWebViewDelegate>

@end
