//
//  StatusTableView.h
//  WeiboCloned
//
//  Created by ZhaoFucheng on 14-8-11.
//  Copyright (c) 2014年 ZhaoFucheng. All rights reserved.
//

#import "BaseTableView.h"

@interface StatusTableView : BaseTableView

@end
