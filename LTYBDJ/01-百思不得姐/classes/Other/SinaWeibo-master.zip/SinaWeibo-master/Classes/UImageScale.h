//
//  UImageScale.h
//  IEStore
//
//  Created by mjlee on 11-3-23.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIImage (scale)

-(UIImage*)scaleToSize:(CGSize)size;

@end